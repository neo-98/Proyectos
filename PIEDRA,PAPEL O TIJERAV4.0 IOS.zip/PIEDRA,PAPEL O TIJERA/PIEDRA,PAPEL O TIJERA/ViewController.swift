//
//  ViewController.swift
//  PIEDRA,PAPEL O TIJERA
//
//  Created by Estudiante on 9/16/19.
//  Copyright © 2019 Estudiante. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Own attributes
    var cpuChoiceEmoji : String?
    
    @IBOutlet weak var CPUShow: UILabel!
    @IBOutlet weak var SelectOptionShow: UILabel!
    @IBOutlet weak var EmojiOptionOne: UIButton!
    @IBOutlet weak var EmojiOptionTwo: UIButton!
    @IBOutlet weak var EmojiOptionThree: UIButton!
    @IBOutlet weak var ButtonResetOption: UIButton!

    @IBOutlet weak var PuntajedeMaquina: UILabel!
    
    

    @IBOutlet weak var Player1Rock: UIButton!
    
    @IBOutlet weak var Player1Paper: UIButton!
    
    
    @IBOutlet weak var Player1Sicssor: UIButton!

    
    @IBOutlet weak var PuntajedePlayer: UILabel!
    
    var puntajePlayerOne=0
    var puntajePlayerTwo=0
    
    var playerNumberOne : Sign?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateGameState(.TurnPlayerOne)
    }
    
    func updateGameState(_ gameState : GameState){
        switch gameState {
        case .TurnPlayerOne:
            CPUShow.text = "😃"
            Player1Rock.setTitle("✊🏻", for: .normal)
            Player1Paper.setTitle("✋🏻", for: .normal)
            Player1Sicssor.setTitle("✌🏻", for: .normal)
            SelectOptionShow.text="Jugador 1: ¿Piedra, papel o tijera?"
           
            ButtonResetOption.isHidden = true
            EmojiOptionOne.isHidden = true
            EmojiOptionTwo.isHidden = true
            EmojiOptionThree.isHidden = true
            
            Player1Rock.isHidden = false
            Player1Paper.isHidden = false
            Player1Sicssor.isHidden = false
            
            self.view.backgroundColor = UIColor.white
            PuntajedePlayer.text = String(puntajePlayerTwo)
            PuntajedeMaquina.text = String(puntajePlayerOne)
        case  .Start:
            CPUShow.text = "😁"
            SelectOptionShow.text="Jugador 2: ¿Piedra, papel o tijera?"

            EmojiOptionOne.setTitle("✊🏽", for: .normal)
            EmojiOptionTwo.setTitle("✋🏽", for: .normal)
            EmojiOptionThree.setTitle("✌🏽", for: .normal)
            ButtonResetOption.isHidden = true
            
            EmojiOptionOne.isHidden = false
            EmojiOptionTwo.isHidden = false
            EmojiOptionThree.isHidden = false
            
            
            Player1Rock.isHidden = true
            Player1Paper.isHidden = true
            Player1Sicssor.isHidden = true
            
            self.view.backgroundColor = UIColor.white
            PuntajedePlayer.text = String(puntajePlayerTwo)
            PuntajedeMaquina.text = String(puntajePlayerOne)
        case .Win:
            CPUShow.text = cpuChoiceEmoji
            SelectOptionShow.text = "Ganaste jugador Numero 2!! :)"
            self.view.backgroundColor = UIColor.green
            ButtonResetOption.isHidden = false
            puntajePlayerOne = puntajePlayerOne - 2
            puntajePlayerTwo = puntajePlayerTwo + 10
            PuntajedePlayer.text = String(puntajePlayerTwo)
            PuntajedeMaquina.text = String(puntajePlayerOne)
            ButtonResetOption.setTitle("Jugar Nuevamente", for: .normal)
            if(puntajePlayerTwo>50){
                ButtonResetOption.isEnabled = false
                PuntajedePlayer.text = String(50)
                ButtonResetOption.setTitle("Ha ganado el jugador", for: .normal)
            }else if(puntajePlayerOne>50){
                ButtonResetOption.isEnabled = false
                PuntajedeMaquina.text = String(50)
                ButtonResetOption.setTitle("Ha ganado la maquina", for: .normal)
            }
        case .Draw:
            CPUShow.text = cpuChoiceEmoji
            SelectOptionShow.text = "Han Empatado los dos jugadores!! :L"
            self.view.backgroundColor = UIColor.blue
            ButtonResetOption.isHidden = false
            puntajePlayerOne = puntajePlayerOne + 5
            puntajePlayerTwo = puntajePlayerTwo + 5
            PuntajedePlayer.text = String(puntajePlayerTwo)
            PuntajedeMaquina.text = String(puntajePlayerOne)
            ButtonResetOption.setTitle("Jugar Nuevamente", for: .normal)
            if(puntajePlayerTwo>50){
                ButtonResetOption.isEnabled = false
                PuntajedePlayer.text = String(50)
                ButtonResetOption.setTitle("Ha ganado el jugador", for: .normal)
            }else if(puntajePlayerOne>50){
                ButtonResetOption.isEnabled = false
                PuntajedeMaquina.text = String(50)
                ButtonResetOption.setTitle("Ha ganado la maquina", for: .normal)
            }
        case .Lose:
            CPUShow.text = cpuChoiceEmoji
            SelectOptionShow.text = "Ha ganado el jugador 1!! :("
            self.view.backgroundColor = UIColor.red
            ButtonResetOption.isHidden = false
            puntajePlayerOne = puntajePlayerOne + 10
            puntajePlayerTwo = puntajePlayerTwo - 2
            PuntajedePlayer.text = String(puntajePlayerTwo)
            PuntajedeMaquina.text = String(puntajePlayerOne)
            ButtonResetOption.setTitle("Jugar Nuevamente", for: .normal)
            if(puntajePlayerTwo>50){
                ButtonResetOption.isEnabled = false
                PuntajedePlayer.text = String(50)
                ButtonResetOption.setTitle("Ha ganado el jugador", for: .normal)
            }else if(puntajePlayerOne>50){
                ButtonResetOption.isEnabled = false
                PuntajedeMaquina.text = String(50)
                ButtonResetOption.setTitle("Ha ganado la maquina", for: .normal)
            }
        }
    }
    
    @IBAction func ResetSelected(_ sender: Any) {
        updateGameState(GameState.TurnPlayerOne)
        EmojiOptionOne.isEnabled = true
        EmojiOptionTwo.isEnabled = true
        EmojiOptionThree.isEnabled = true
    }
    
    @IBAction func EmojiOneSelected(_ sender: Any) {
        //let playerSign = Sign.rock
        compararEmoji(Sign.rock)
        EmojiOptionOne.isEnabled = false
        EmojiOptionTwo.isHidden = true
        EmojiOptionThree.isHidden = true
    }
    
    @IBAction func EmojiTwoSelected(_ sender: Any) {
        //let playerSign = Sign.paper
        compararEmoji(Sign.paper)
        EmojiOptionTwo.isEnabled = false
        EmojiOptionOne.isHidden = true
        EmojiOptionThree.isHidden = true
    }
    
    @IBAction func EmojiThreeSelected(_ sender: Any) {
        //let playerSign = Sign.scissors
        compararEmoji(Sign.scissors)
        EmojiOptionThree.isEnabled = false
        EmojiOptionOne.isHidden = true
        EmojiOptionTwo.isHidden = true
    }
    
    
    
    @IBAction func ButtonRockPlayerOne(_ sender: Any) {
        playerNumberOne = .rock
        updateGameState(.Start)
    }
    
    
    @IBAction func ButtonPaperPlayerOne(_ sender: Any) {
        playerNumberOne = .paper
        updateGameState(.Start)
    }
    
    
    @IBAction func ButtonScissorsPlayerOne(_ sender: Any) {
        playerNumberOne = .scissors
        updateGameState(.Start)
    }
    
    
    
    func compararEmoji(_ sign: Sign){
        //let playerSign = sign
        //let cpuSign = randomSign()
        //cpuChoiceEmoji = cpuSign.emoji
        let gameState = sign.play(playerNumberOne!)
        updateGameState(gameState)
    }
    
}
