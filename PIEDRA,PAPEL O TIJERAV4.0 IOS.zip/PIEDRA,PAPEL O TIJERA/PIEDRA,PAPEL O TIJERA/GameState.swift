//
//  GameState.swift
//  PIEDRA,PAPEL O TIJERA
//
//  Created by Estudiante on 9/16/19.
//  Copyright © 2019 Estudiante. All rights reserved.
//

import Foundation
enum GameState {
    case Start
    case Win
    case Lose
    case Draw
    case TurnPlayerOne
}
