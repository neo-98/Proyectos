//
//  Sign.swift
//  PIEDRA,PAPEL O TIJERA
//
//  Created by Estudiante on 9/16/19.
//  Copyright © 2019 Estudiante. All rights reserved.
//

import Foundation
import GameplayKit

//let randomChoice = GKRandomDistribution(lowestValue: 0, highestValue: 2)
//var puntajeMaquina=0
//var puntajePlayer=0


//func PuntajeJuego(_ puntajeM : Int, _ puntajeP : Int){
//    puntajeMaquina += puntajeM
//    puntajePlayer += puntajeP
//}

//func randomSign() -> Sign{
 //   let sign = randomChoice.nextInt()
 //)   switch sign {
//    case 0:
//        return .rock
//    case 1:
//        return .paper
//    default:
//        return .scissors
//    }
//}

enum Sign{
    case rock
    case paper
    case scissors
    
    var emoji : String{
        switch self {
        case .rock:
            return "👊🏻"
        case .paper:
            return "🤚🏻"
        case .scissors:
            return "✌🏻"
        }
    }
    
    func play(_ cpuSign: Sign) -> GameState{
        switch self {
        
        //User sets Roch
        case .rock:
            //CPU Choice
            switch cpuSign{
            case .rock:
                return .Draw
            case .paper:
                return .Lose
            case .scissors:
                return .Win
            }
        
        //User sets Roch
        case .paper:
            //CPU Choice
            switch cpuSign{
            case .paper:
                return .Draw
            case .rock:
                return .Win
            case .scissors:
                return .Lose
            }
            
        
        //User sets Roch
        case .scissors:
            //CPU Choice
            switch cpuSign{
            case .rock:
                return .Lose
            case .paper:
                return .Win
            case .scissors:
                return .Draw
            }
        }
    }
}


