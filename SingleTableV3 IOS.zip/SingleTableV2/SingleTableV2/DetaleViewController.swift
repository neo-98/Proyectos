//
//  DetaleViewController.swift
//  SingleTableV2
//
//  Created by Estudiante on 10/2/19.
//  Copyright © 2019 Estudiante. All rights reserved.
//

import UIKit

class DetaleViewController: UIViewController {

    var dataTitle : String?
    
    @IBOutlet weak var detaleViewController: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        detaleViewController.text = dataTitle
    }

}
