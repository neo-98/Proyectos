//
//  ViewController.swift
//  SingleTableV2
//
//  Created by Estudiante on 9/30/19.
//  Copyright © 2019 Estudiante. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    let data = ["Motorola", "Samsung", "Xiaomi","Iphone"]
    let tableCell = "tableCell"
    let segueDetail = "segueDetail"
    
    @IBOutlet weak var tableView: UITableView!
    
    
    //Outlets
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }

    
    //
    func numberOfSectionInTableView(tableView : UITableView)-> Int{
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: tableCell, for: indexPath)
        
        let row = indexPath.row
        cell.textLabel?.text = data[row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let row = indexPath.row
        print(data[row])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueDetail{
            let destination = segue.destination as? DetaleViewController
            let index = tableView.indexPathForSelectedRow?.row
            destination?.dataTitle = data[index!]
        }
    }
}

